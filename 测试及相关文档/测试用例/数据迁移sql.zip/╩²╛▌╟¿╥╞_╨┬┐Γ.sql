--�̼ҷ���
select * from mb_business_classify order by caption asc;
select c1.id,c2.caption,c1.caption from mb_business_classify c1 left join  mb_business_classify c2 on c1.pid=c2.id
/*
delete from mb_business_classify where caption in ('df',
'��������',
'�Ҿ߽���',
'�ҾӼҷ�',
'�ҵ�칫',
'�ֻ�����',
'������ױ',
'�Ļ�����',
'���ðٻ�',
'��װ����',
'ĸӤ��Ʒ',
'����Ħ��',
'�鱦�ֱ�',
'�������',
'�˶�����',
'Ь������',
'ʳƷ����')
*/

--�̼ҷ����ϵ��
select t.*,t.rowid from mb_business_classify_relation t;
select
r.businessid,
(select b.name from mb_business b where b.id=r.businessid) business,
(select c.caption from mb_business_classify c where c.id=r.classifyid) classify
 from mb_business_classify_relation r where r.businessid not in  
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);
--�û���Ϣ
select phone,count(*) from mb_user group by phone;
select * from mb_user_privilege;
select * from mb_user_role;
select * from mb_user_role_privilege;
select * from mb_user order by phone asc;
select * from mb_user_role_relation;
--�û���
select * from mb_user order by phone asc;
select * from mb_user where createdate<to_date('2014/7/16 18:05:43','yyyy-mm-dd hh24:mi:ss') order by phone asc;
select count(*) from mb_user where createdate<to_date('2014/7/16 18:04:43','yyyy-mm-dd hh24:mi:ss') and status = 0;
--  delete from mb_user where (phone not like '17%') and (phone not like '10%');
select * from mb_user_role_relation where userid not in (select id from mb_user);
--
--�û���ɫ��ϵ��

select * from mb_user_role_relation where 
roleid='U000002' AND
userid   in
 (select id from mb_user where createdate<to_date('2014/7/16 18:05:43','yyyy-mm-dd hh24:mi:ss'));

select * from mb_user_role;
--�û�΢����Ϣ
select * from mb_weixin_user;

--�û�Ǯ��
select * from mb_user_wallet


--Ʒ����Ϣ/��ַ
select * from mb_business order by indate asc;
select * from mb_business where indate < to_date('2014/7/5 15:59:00','yyyy-mm-dd hh24:mi:ss');
select * from mb_business_role_relation;
/*
delete from mb_business where id not in  
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);
*/
--Ʒ���˺�
select * from mb_businesser where businessid not in 
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);
/*
delete from mb_businesser where businessid not in 
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);
*/
select (select b.name from mb_business b where b.id=r.businessid),r.* from mb_businesser r 

select * from mb_businesser_role_relation;

--�̼���ϵ��
select * from mb_business_contract  where businessid not in 
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);
/*
delete from mb_business_contract  where businessid not in 
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);

*/


--�̼����п�
select * from mb_business_card;

--�̼�Ǯ��
select * from mb_business_wallet;
select * from mb_business_flow;

--�̼����¼���ϵ
select t.*, t.rowid from mb_business_relation t;
/*
delete from mb_business_relation  where businessid not in 
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);

*/
--�̼ҽ���
select t.*, t.rowid from mb_pay_assign t;
/*
delete from mb_business_role_relation  where businessid not in 
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);

*/

--�̼ҽ�ɫ
select * from mb_business_role_relation;
select (select r.caption from mb_business_role r where r.id=t.roleid) ,t.businessid,t.disabledate 
from mb_business_role_relation t
where businessid not in (
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);
select * from mb_business_role;
/*
delete from mb_business_role_relation  where businessid not in 
(
select id from mb_business where indate > to_date('2014/6/1 15:59:00','yyyy-mm-dd hh24:mi:ss')
);

*/

--�ڶӶ���
select * from mb_order_inqueue;
SELECT * FROM MB_ORDER_INQUEUE WHERE ORDERNO='MO05S8V3M7G8NY0E6P';
--delete from mb_order_inqueue;

--�û�֧����Ϣ
 
select * from mb_user_pay where resume not like '��Ա��'
--delete from mb_user_pay where resume not like '��Ա��'
--ԭ������
select * from mb_user_pay where resume like '��Ա��'