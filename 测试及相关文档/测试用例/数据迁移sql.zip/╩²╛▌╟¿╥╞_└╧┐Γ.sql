select * from mb_user_pay t;
select * from mb_user_info where phonenumber like '%1912%';
select phonenumber,count(*) from mb_user_info group by phonenumber;
select t.*,t.rowid from mb_user_info t order by t.phonenumber desc;
select * from mb_delivery_address;

select t.*,t.rowid from mb_user_info t where id = 144;
--update mb_user_info set createdate = add_months(createdate,-1)where id =144
--���ֻ�������û���Ϣ

select * from (select t.*,(select a.mobile from mb_delivery_address a where a.userid=t.id and rownum=1) AN from mb_user_info t ) 
where ((phonenumber is not null) or (an is not null))

 AND PHONENUMBER IN (SELECT MOBILE FROM MB_DELIVERY_ADDRESS WHERE MOBILE IS NOT NULL) AND PHONENUMBER <> AN


select x.* from 
(select * from (select t.*,(select a.mobile from mb_delivery_address a where a.userid=t.id and rownum=1) AN from mb_user_info t ) 
where ((phonenumber is not null) or (an is not null))) x
where x.an not in 
(
 select x.phonenumber from (select * from (select t.*,(select a.mobile from mb_delivery_address a where a.userid=t.id and rownum=1) AN from mb_user_info t ) 
where ((phonenumber is not null) or (an is not null))) x
 where x.phonenumber not in (select x.phonenumber from 
       (select * from (select t.*,(select a.mobile from mb_delivery_address a where a.userid=t.id and rownum=1) AN from mb_user_info t ) 
where ((phonenumber is not null) or (an is not null))) x where x.phonenumber = x.an) 
or x.phonenumber is null
)
or x.an is null


---
select t1.phonenumber from (select * from (select t.*,(select a.mobile from mb_delivery_address a where a.userid=t.id and rownum=1) AN from mb_user_info t ) 
where ((phonenumber is not null) or (an is not null))) t1
where t1.phonenumber in 

()


select * from (select t.*,(select a.mobile from mb_delivery_address a where a.userid=t.id and rownum=1) AN from mb_user_info t ) 
--�û���ַ
select * from MB_DELIVERY_ADDRESS


--�û���Ϣ
select t.*,t.rowid from mb_user_info t order by t.phonenumber desc;
--�û���Ա��Ϣ
select t.status,t.id,t.logindate from mb_user_info t where t.logindate>to_date('0001/1/1 00:00:00','yyyy-mm-dd hh24:mi:ss');

--�û�΢����Ϣ
select * from mb_weixin_user;

--�û�Ǯ��
select * from mb_user_cash;

--��Ʒ��Ϣ
select * from mb_allorder_goods;
select * from mb_allorder_goods where title like '%okia%';
select sum(count) from mb_order_details t where t.goodsid = '243';
--����
select sum(count) from mb_order_details  a left join mb_order_buys b on a.orderno = b. orderno where b.del=0 and a.goodsid= 243
--ͼƬ
--iphone 5s 0e41a6a58d534d3e9636a6ae378a6327
--Nokia 013f9611ad9a42fda0a731491a982c4d
select * from mb_goods_images_path t where t.goodsguid='0e41a6a58d534d3e9636a6ae378a6327';

select * from mb_after_sales;
--��Ʒ����
select count(*) from mb_user_evaluation;
select t.*,t.rowid from mb_user_evaluation t where goodsid=243;

select t.* ,ur.account,ur.phonenumber,ur.email,ur.nickname,img.imagepath,ur.isloadpic  from mb_user_evaluation t  left join  mb_user_info ur on t.userid=ur.id  
                          left join mb_user_images_path img on t.userid=img.userid  
                           where t.goodsid= 243 order by t.createdate desc
--�̼ҷ���
select * from mb_shop_type order by topclassify desc,floorclassify asc;
select distinct(topclassify) from mb_shop_type;
select * from mb_brand_type;

--Ʒ����Ϣ
select * from mb_brand_info;
select * from mb_shop_info;

select * from mb_brand_type;
select * from mb_shop_type;
--Ʒ����������  ��Ӧ��������
SELECT * FROM MB_BRAND_TYPE;
select t.brandid,
(select b.brandname from mb_brand_info b where b.id=t.brandid),
(select s.topclassify from mb_shop_type s where s.id=t.shoptype)
 from mb_brand_type t;
 
--Ʒ�ƽ�ɫ

select t.id,t.brandname, t.mallrights
from mb_brand_info t;  
--Ʒ�Ƶ�ַ
select * from mb_brand_address;
select a.brandid,(select b.brandname from mb_brand_info b where b.id= a.brandid ) bname
,(select provinceid from mb_addr_town n where n.id=t.townid) pid
,t.townid
,a.* from mb_brand_address a left join mb_addr_area t on a.areaid=t.id;

select * from mb_addr_province;
select * from mb_addr_town;
select * from mb_addr_area;
--Ʒ���˺�/��ϵ����Ϣ
select b.*,  s.shopkeeper,s.phonenumber,s.mail,s.createdate   from mb_brand_info b left join mb_shop_info s on s.id=b.shopid;

select b.account,b.password,b.id,   s.shopkeeper,s.phonenumber,s.mail,s.createdate   from mb_brand_info b left join mb_shop_info s on s.id=b.shopid;
--�̼����п�
select c.*,b.brandname from mb_brand_card_info c left join mb_brand_info b on c.brandid=b.id;

select * from mb_brand_type;
 
--�̼�Ǯ��
select * from mb_brand_cash;

--�ڶӶ���
select recordno, queuerecordid, orderno,(select s.name from mb_shop_info s where s.id= shopid ) shopname , userid, fee, ordercreatedate, inqueuedate, remark, rebackfee, storagedate, registerid, status, origin from mb_order_inqueue;
SELECT * FROM MB_ORDER_INQUEUE WHERE ORDERNO='MO05S8V3M7G8NY0E6P';

--�û�֧����Ϣ ��ת������֧���ɹ���¼ type=0 and status =1
select * from mb_user_pay
select * from mb_user_pay where type=0 and status =1;
